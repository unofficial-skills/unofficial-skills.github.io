#!/usr/bin/env python3

#    Copyright (c) 2018 Penn Mackintosh
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.

# N.B. I do not assert any copyright claim on either twrp-kirin.img or libusb-1.0.dll. If the authors want me to remove them, I will.


DEBUG=True
DISABLE_CHECKS=False
DISABLE_DLOAD=False
DISABLE_SLOCK=False
DISABLE_FBLOCK=False
DISABLE_TWRP=False
DISABLE_NVME=False


def err(reason):
    print('ERROR: '+str(reason))
    print('Aborting...')
    exit(1)

def dbg(reason):
    if DEBUG:
        print('DEBUG: '+str(reason))

def info(reason):
    print(str(reason))

print('╔═════════════════════════════════════════════════════════════════════════════════════════════╗')
print('║┌───╮                       ╷    ╷                                                           ║')
print('║│   │ ───┬───  ╭──────╮     │    │ │    │     ╱╲     ╲            ╱  ┌────   ───┬───         ║')
print('║├───┴╮   │     │            ├────┤ │    │    ╱  ╲     ╲          ╱   │          │            ║')
print('║│    │   │     │            │    │ │    │   ╱────╲     ╲        ╱    ├───       │            ║')
print('║│    │   │     │      ╮     │    │ │    │  ╱      ╲     ╲  ╱╲  ╱     │          │            ║')
print('║└────╯ ──┴──   ╰──────╯     ╵      ╰────╯ ╱        ╲     ╲╱  ╲╱      └────    ──┴──          ║')
print('║                                                                                             ║')
print('║┌─────                       ____   ───┬───  ───┬───  ────────    ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ    ║')
print('║│       ╲  ╱  ╭───╮  │      ╱ __ ╲     │        │            ╱     ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ   ║')
print('║├────    ╲╱   │   │  │     │ │  │ │    │        │           ╱    ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ║')
print('║│        ╱╲   ├───╯  │     │ │__│ │    │        │          ╱    ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ  ║')
print('║│       ╱  ╲  │      │      ╲____╱     │        │         ╱    ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ ಠ‿ಠ   ║')
print('║└───── ╱    ╲ │      ╰────           ──┴──      ╵         ────────                           ║')
print('╚═════════════════════════════════════════════════════════════════════════════════════════════╝')

try:
    import pip
    def install(args):
        if hasattr(pip, 'main'):
            pip.main(['install']+args)
        else:
            import pip._internal
            pip._internal.main(['install']+args)
        err('Please rerun the script')
except ImportError:
    def install(args):
        print('Please install pip3 or the following dependencies to your system')
        err(args)
try:
    from lxml import html
except ImportError:
    install(['lxml'])
try:
    import rsa
except ImportError:
    install(['rsa'])
try:
    import requests
except ImportError:
    install(['requests'])

print('Dependency installation: `wget https://github.com/google/python-adb/archive/master.zip;unzip master.zip;cd master;cd python-adb-master;pip3 install -e .`')
try:
    from adb import adb_commands
    from adb import sign_pythonrsa
    from adb import fastboot
    from adb import usb_exceptions
except ImportError as e:
    print(e)
    import urllib3, tempfile, shutil, zipfile, os
    url = 'https://github.com/google/python-adb/archive/master.zip'
    http = urllib3.PoolManager()
    with tempfile.TemporaryFile() as f:
        with http.request('GET', url, preload_content=False) as r:
            shutil.copyfileobj(r, f)
        with zipfile.ZipFile(f) as z:
            z.extractall('python-adb')
            install(['-e', os.path.join('python-adb', 'python-adb-master')])

from io import BytesIO
import os, json, re, zipfile, tempfile, shutil, time

def device_checks(device):
    if DISABLE_CHECKS:
        return
    platform = getprop('ro.product.platform', device)
    if platform[0:2] != 'hi':
        err('Only Kirin devices are supported, you have '+platform[0:2])
    elif platform == 'hi3670':
        err('Kirin970 is not supported. Sorry')
    else:
        dbg('platform='+platform)
    sdklevel = getprop('ro.build.version.sdk', device)
    if sdklevel != '26':
        err('Only Android Oreo 8.0 is supported, you have '+str(sdklevel))
    else:
        dbg('sdklevel='+sdklevel)

def check_dload_required(device):
    if DISABLE_DLOAD:
        return False
    secpatch = getprop('ro.keymaster.xxx.security_patch', device)
    if not secpatch: #If the prop doesnt exist
        secpatch = getprop('ro.build.version.security_patch', device)
    yyyy=int(secpatch[0:4])
    mm=int(secpatch[5:7])
    dd=int(secpatch[8:10])
    dbg('date='+str(dd)+'/'+str(mm)+'/'+str(yyyy))
    if (yyyy == 2018 and mm > 6) or yyyy > 2018:
        dbg('Downgrade required, will automatically dload firmware for you. Data may be lost')
        return True
    else:
        dbg('Already before June 2018, no downgrade needed')
        return False

class BuildGetter():
    def __init__(self):
        self.model = None
        self.build = None
        self.region = None
    def handle(self, message):
        if message.header == b'INFO':
            dbg(message.message)
            mess = re.search(b'([A-Z]{3}-[A-Z0-9]{3}) 8\.0\.[0-9]*\.([0-9]*)\(C([0-9]{1,3})\)', message.message)
            if mess:
                dbg(mess.group(0))
                self.model = mess.group(1)
                self.build = mess.group(2)
                self.region = mess.group(3)
    def get_build(self):
        return self.build.decode('utf8')
    def get_model(self):
        return self.model.decode('utf8')
    def get_region(self):
        return self.region.decode('utf8')

def check_dload_required_fastboot(fdevice):
    if DISABLE_DLOAD:
        return False
    buildgetter = BuildGetter()
    build = fdevice.Oem('get-build-number', info_cb=buildgetter.handle)
    checks = requests.get('https://pro-teammt.ru/firmware-database/', params={'firmware_model': buildgetter.get_model()+'C'+buildgetter.get_region()+'B'+buildgetter.get_build()}).content
    date = extract_date_teammt(checks, buildgetter.get_model()+'C'+buildgetter.get_region()+'B'+buildgetter.get_build())
    dbg(date)

def extract_date(res):
    date = re.search(r'<p>Dated Uploaded: ([0-9]{2}/[0-9]{2}/[0-9]{4})', res[0]).group(1)
    return date[6:10]+date[3:5]+date[0:2]

def extract_url(res):
    return re.search(r'<a href="(https://androidhost.ru/[a-zA-Z0-9]{3})"', res[1]).group(1)

def extract_build_number(res):
    return 'B'+re.search(r'8\.0\.[0-9]*\.([0-9]*)', res[0]).group(1)

def extract_date_teammt(page, modelstring):
    tree = html.fromstring(page)
    date = tree.xpath(r'//table[@class="tablesorter"]/tr/td[text()="FullOTA-MF"]/../td[1]/text()')
    return date[0]

def get_dload_url(file_url):
    page = requests.get(file_url).text
    script = re.search(r"<!-- DOWNLOAD -->\n<script>\n(?:.|\n)*?<a class='btn btn-default' href='(https://androidhost\.ru/.*?%3D)'>", page, re.DOTALL).group(1)
    return script

def find_dload_firmware_url(model, region, strict=True):
    data = requests.get('https://androidhost.ru/ajax/_search.ajax.php', params={'sEcho':'11','iColumns':'2','sColumns':'','iDisplayStart':'0','iDisplayLength':'400','filterText':model,'filterType':''}).json()
    res = data['aaData']
    valid = []
    for result in res:
        if region in result[0] or not strict:
            valid.append(result)
    valid = sorted(valid, key=extract_date, reverse=False) #Sort by date uploaded, uploaded first comes first.
    date = extract_date(valid[0])
    if (int(date[0:4]) == 2018 and int(date[4:6]) > 6) or int(date[0:4]) > 2018:
        dbg('No firmware confirmed available for this model and region variant old enough for this exploit.')
        checks = requests.get('https://pro-teammt.ru/firmware-database/', params={'firmware_model': model+'C'+region+extract_build_number(valid[0])}).content
        date = extract_date_teammt(checks, model+'C'+region+extract_build_number(valid[0]))
        dbg('date='+date)
        if (int(date[0:4]) == 2018 and int(date[5:7]) > 6) or int(date[0:4]) > 2018:
            err('No firmware available for this model and region variant old enough for this exploit. Please manually downgrade to June 2018.')
    url = get_dload_url(extract_url(valid[0]))
    cookies = {'filehosting': 'rmlhrqp2ob72j9dbvd3s63rlr0'}
    r = requests.get(url, cookies=cookies, allow_redirects=False)
    if r.status_code == 302:
        dbg('got it first try!')
        return requests.Request('GET', r.headers['Location'], cookies=cookies).prepare()
    else:
        dbg('second try')
        return requests.Request('GET', url, cookies=cookies).prepare()

def install_firmware(response, device):
    storage = device.Shell('sh -c "if [ -d /external_sd ]; then echo /external_sd; else echo /storage/[0-9][0-9][0-9][0-9]-[0-9][0-9][0-9][0-9]; fi"', timeout_ms=1000)
    with dloadfirmware as r:
        info('Downloading up to 3gb of files, may time some time')
        with tempfile.TemporaryFile() as f:
            shutil.copyfileobj(r.raw, f)
            with tempfile.TemporaryDirectory() as d:
                info('extracting files')
                zipf = zipfile.ZipFile(f)
                zipf.extractall(d)
                zipf.close()
                info('Copying files over usb, will take up to 3 hours')
                device.Push(os.path.join(d, 'Software', 'dload'), '/data/local/tmp/dload')
                info('Moving files')
                device.Shell('mv /data/local/tmp/dload '+storage, timeout_ms=1000000)
                info('Firmware ready for install, please open dialer on phone and dial *#*#2846579#*#* then select 4->1.')
                device.Shell('while :;do sleep 99999;done')
                device = connect_adb()
                if check_dload_required(device):
                    err('dload appears to have failed! downgrade manually!')
                else:
                    dbg('dload success')
                    return True

def patch_nvme(nvm):
    if DISABLE_NVME:
        return nvm
    nvme = bytearray(nvm)
    loc = nvme.find(b'FBLOCK')
    while loc != -1:
        nvme[loc+12]=0
        loc = nvme.find(b'FBLOCK', loc+12)
        dbg(loc)
    return bytes(nvme)

class FblockGetter():
    def __init__(self):
        self.fblock = None
    def handle(self, message):
        if message.header == b'INFO' and message.message[0:6] == b'FBLOCK':
            dbg(message.message)
            self.fblock = message.message
    def get_fblock(self):
        return self.fblock

def generate_fblock(fdevice):
    if DISABLE_FBLOCK:
        return b''
    fblock_gen = FblockGetter()
    fdevice.Oem('hwdog certify begin', info_cb=fblock_gen.handle)
    return fblock_gen.get_fblock()

def flash_slock(slock, fdevice):
    if DISABLE_SLOCK:
        return
    try:
        int(slock, 16)
    except ValueError:
        f = open(slock, 'rb')
        slock = f.read().decode('utf8')
        int(slock, 16)
    if len(slock) == 512:
        slock = bytes.fromhex(slock)
    else:
        slock = slock.encode('utf8')
    assert len(slock) == 256
    return fdevice.FlashFromFile('slock', BytesIO(slock), 256)

def connect_fastboot():
    while True:
        try:
            return fastboot.FastbootCommands().ConnectDevice()
        except usb_exceptions.DeviceNotFoundError:
            pass

def connect_adb():
    signer = sign_pythonrsa.PythonRSASigner(open(os.path.expanduser('~/.android/adbkey.pub')).read(), open(os.path.expanduser('~/.android/adbkey')).read())
    device = adb_commands.AdbCommands()
    while True:
        try:
            device.ConnectDevice(rsa_keys=[signer])
            return device
        except usb_exceptions.DeviceNotFoundError:
            pass

def flash_twrp(fdevice):
    if DISABLE_TWRP:
        return
    return fdevice.FlashFromFile('erecovery_ramdisk', open(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'twrp-kirin.img'), 'rb'))

def check_root(device):
    return device.Shell('whoami') == b'root'

def get_nvme(device):
    device.Shell('dd if=/dev/block/bootdevice/by-name/nvme of=/tmp/nvme')
    nvm = device.Pull('/tmp/nvme')
    nnvm = BytesIO(patch_nvme(nvm.read()))
    return nnvm

class LockstatGetter():
    def __init__(self):
        self.lockstat = None
    def handle(self, message):
        if message.header == b'INFO' and self.lockstat == None:
            dbg(message.message)
            self.lockstat = message.message.decode('utf8')
    def get_lockstat(self):
        return re.search('(U?N?)LOCKED', self.lockstat).group(1) == 'UN'

def get_lockstat(fdevice):
    lockstat = LockstatGetter()
    fdevice.Oem('get-bootinfo', lockstat.handle)
    return lockstat.get_lockstat()

def getprop(prop, device):
    return device.Shell('getprop '+prop).strip()

def init():
    print('Welcome. This tool will automatically root your phone, with very little manual input needed. All data will probably be lost. There is a small risk your phone will be bricked, either permanently or temporarily')
    input('Please connect your phone and enable ADB (only applicable if booted, nothing needed if in fastboot), then press enter.')

def main():

    init()

    try:
        fdevice = fastboot.FastbootCommands().ConnectDevice()
        device = None
    except usb_exceptions.DeviceNotFoundError:
        device = connect_adb()
        fdevice = None
    if device != None:
        device_checks(device)
        if check_dload_required(device):
            dloadfirmware = requests.Session().send(find_dload_firmware_url(getprop('ro.product.model', device), getprop('ro.product.CustCVersion', device)), stream=True)
            dbg('firmware status = '+str(install_firmware(dloadfirmware, device)))
        device.RebootBootloader()
    else:
        if check_dload_required_fastboot(fdevice):
            err("Firmware downgrade is not automated in fastboot mode. Please downgrade manually.")
    del device


    fdevice = connect_fastboot()
    info('Do not disconnect device...')
    info(generate_fblock(fdevice).decode('utf8').strip())
    info('Good things are happening, but your device still hasn\'t been unlocked... To do that, please ask @OldDroid for your slock key. To generate this, he will need the `FBLOCK` code written above.')
    if not DISABLE_SLOCK:
        while True:
            try:
                flash_slock(input('Please enter either the path to the `res` file or the raw slock code, then press enter: ').strip(), fdevice)
                break
            except fastboot.FastbootRemoteFailure as e:
                info('Something went wrong...')
                dgb(e)
    dbg(flash_twrp(fdevice))
    input('Alright! TWRP (a custom recovery) has been installed to your device. HURRAY! But wait, you can\'t yet root or install a custom ROM because it would brick the phone. There\'s one step left to go. Please wait for the phone to vibrate, then hold volume up.')

    fdevice.Reboot()
    del fdevice

    device = connect_adb()

    if not check_root(device):
        device.Reboot(b'erecovery')
        time.sleep(7) #Sometimes, adb stays online for some time after we trigger a reboot.
        device = connect_adb()

    if not DISABLE_NVME:
        input('OK! Now press enter to begin the dangerous part of the unlocking, or CTRL+C to cancel.')
        nvm = get_nvme(device)
        device.Push(nvm, '/tmp/nvme')
        device.Shell('dd if=/tmp/nvme of=/dev/block/bootdevice/by-name/nvme')

    info('Bootloader should be unlocked now, verifying...')

    device.RebootBootloader()
    fdevice = connect_fastboot()

    info('Bootloader unlock state: '+str(get_bootinfo(fdevice)))

if __name__ == '__main__':
    main()
